# Change Log

## [1.0.1] 2022-08-31
### Bug Fixing
- refactor custom classes
- add pro button

## [1.0.0] 2022-07-29
### Original Release